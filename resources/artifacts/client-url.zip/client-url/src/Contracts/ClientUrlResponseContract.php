<?php
/**
 * Created by PhpStorm.
 * User: Ian Moreno <ian.moreno@republisys.com>
 * Date: 9/29/17 1:54 PM 
 */

namespace Rzian\ClientUrl\Contracts;

interface ClientUrlResponseContract
{
    /**
     * Class constructor.
     *
     * @param array $content
     * @param string $error
     * @param string $status
     * @param int $code
     */
    public function __construct($content, $error, $status, $code);

    /**
     * Class magic getter for data collection.
     *
     * @param string $name
     * @return mixed
     */
    public function __get($name);

    /**
     * Class magic setter for data collection.
     *
     * @param string $name
     * @param mixed $value
     * @return void
     */
    public function __set($name, $value);
    /**
     * Class magic isset checker of data key
     *
     * @param string $name
     * @return bool
     */
    public function __isset($name);

    /**
     * Class magic unset of data key and its value.
     *
     * @param string $name
     * @return bool
     */
    public function __unset($name);

    /**
     * Retrieve HTTP status.
     *
     * @return string
     */
    public function getStatus();

    /**
     * Retrieve HTTP status code.
     *
     * @return int
     */
    public function getStatusCode();

    /**
     * Validates error response.
     *
     * @return bool
     */
    public function isError();

    /**
     * Retrieves error status code.
     *
     * @return int|null
     */
    public function getErrorCode();

    /**
     * Retrieves error status.
     *
     * @return null|string
     */
    public function getErrorStatus();

    /**
     * Retrieves error message content.
     *
     * @return string|null
     */
    public function getErrorMessage();

    /**
     * Convert content to array values
     *
     * @return array
     */
    public function toArray();

    /**
     * Convert content to JSON string value.
     *
     * @return string
     */
    public function toJson();
}