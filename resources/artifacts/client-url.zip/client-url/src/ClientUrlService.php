<?php
/**
 * Created by PhpStorm.
 * User: Ian Moreno <ian.moreno@republisys.com>
 * Date: 9/29/17 2:06 PM 
 */

namespace Rzian\ClientUrl;

use Rzian\ClientUrl\ClientUrlResponse;

class ClientUrlService 
{
    /**
     * Client configuration handler
     * 
     * @var array
     */
    private $_config;

    /**
     * Header collection handler
     * 
     * @var array(
     *  'accept' => 'application/json',
     *  'content-type' => 'application/json'
     * )
     */
    private $_headers = array();

    /**
     * cUrl option handler
     * 
     * @var array
     */
    private $_options = array();

    /**
     * The constructor class.
     *
     * @param array $config
     */
    public function __construct($config = array())
    {
        $this->_config = $config;
    }

    /**
     * @param string $name
     * @return null|string
     */
    final public function __get($name)
    {
        if (! array_key_exists($name, $this->_config))
        {
            return null;
        }

        return $this->_config[$name];
    }

    /**
     * @param string $name
     * @param mixed $value
     * return void
     */
    final public function __set($name, $value)
    {
        $this->_config[$name] = $value;
    }

    /**
     * Alias for request method GET.
     *
     * @param $route
     * @param array $params
     * @return ClientUrlResponse
     */
    final public function get($route, $params = array())
    {
        return $this->request('get', $route, $params);
    }

    /**
     * Alias for request method POST.
     *
     * @param $route
     * @param array $params
     * @return ClientUrlResponse
     */
    final public function post($route, $params = array())
    {
        return $this->request('post', $route, $params);
    }

    /**
     * Alias for request method PATCH.
     *
     * @param $route
     * @param array $params
     * @return ClientUrlResponse
     */
    final public function patch($route, $params = array())
    {
        return $this->request('patch', $route, $params);
    }

    /**
     * Alias for request method PATCH.
     *
     * @param $route
     * @param array $params
     * @return ClientUrlResponse
     */
    final public function put($route, $params = array())
    {
        return $this->request('put', $route, $params);
    }

    /**
     * Alias for request method DELETE.
     *
     * @param $route
     * @param array $params
     * @return ClientUrlResponse
     */
    final public function delete($route, $params = array())
    {
        return $this->request('delete', $route, $params);
    }

    /**
     * CUrl request interface.
     *
     * @param string $method
     * @param string $route
     * @param array $params
     * @return ClientUrlResponse
     */
    final public function request($method, $route, $params = array())
    {        
        if (! in_array($method = strtoupper($method), ['GET', 'POST']))
        {
            $params['_method'] = $method;
            $method = 'POST';
        }

        if ($this->url)
        {
            $route = $this->url.$route;
        }

        $request = curl_init($route); curl_setopt_array($request, $this->_options(array(
            CURLOPT_HTTPHEADER => $this->_headers(),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_POSTFIELDS => $this->_serialize($params)
        )));

        $response = json_decode(curl_exec($request), true);
        $code = (int)curl_getinfo($request, CURLINFO_HTTP_CODE);
        $status = $this->_status($code);
        $error = curl_error($request);
        curl_close($request);

        return new ClientUrlResponse($response, $error, $status, $code);
    }

    /**
     * Retrieves request header options.
     *     
     * @return array
     */
    private function _headers()
    {
        $headers = array();
        if (sizeof($this->_headers) > 0)
        {
            foreach($this->_headers as $key => $value)
            {
                $headers[] = sprintf('%s: %s', ucwords($key, ' -'), $value);
            }
        }

        return $headers;
    }

    /**
     * Retrieves Http status message.
     *
     * @param int $code
     * @return string
     */
    private function _status($code)
    {
        $status = 'Undefined';
        switch ($code)
        {
            case 200: $status = 'OK'; break;
            case 201: $status = 'Created'; break;
            case 204: $status = 'No Content'; break;
            case 304: $status = 'Not Modified'; break;

            case 400: $status = 'Bad Request'; break;
            case 401: $status = 'Unauthorized'; break;
            case 403: $status = 'Forbidden'; break;
            case 404: $status = 'Not Found'; break;
            case 405: $status = 'Method Not Allowed'; break;
            case 409: $status = 'Conflict'; break;
            case 415: $status = 'Unsupported Media Type'; break;
            case 422: $status = 'Unprocessable Entity'; break;

            case 500: $status = 'Internal Server Error'; break;
            case 503: $status = 'Service Unavailable'; break;
        }

        return $status;
    }

    /**
     * Retrieves cUrl modifier options.
     *
     * @param array $options
     * @return array
     */
    private function _options($options = array())
    {
        if (sizeof($this->_options) > 0)
        {
            $options += $this->_options;
        }

        return $options;
    }

    /**
     * @param array $params
     * @return string
     */
    private function _serialize(array $params)
    {
        if (array_key_exists('content-type', $this->_headers) && strtolower($this->_headers['content-type']) == 'application/json')
        {
            return json_encode($params);
        }

        return $params;
    }

     /**
     * Aggresively serialize the parameter before sending to cUrl postfield option.
     *
     * @param array $params
     * @return mixed
     */
    /*private function __deepSerialize($params) 
    {
        $parameters = array();
        foreach ($params as $key => $value) {
            $parameters[urlencode($key)] = urlencode($value);
        }

        return $parameters;
    }*/

    /**
     * For additional request header options.
     *
     * @param string|array $name
     * @param mixed $value
     * @return $this
     */
    public function header($name, $value = false)
    {
        if (is_array($name))
        {
            foreach ($name as $key => $value)
            {
                $this->header($key, $value);
            }

            return $this;
        }

        $this->_headers[strtolower($name)] = $value;
        return $this;
    }

    /**
     * For additional cUrl options.
     *
     * @param int|array $modifier
     * @param mixed $value
     * @return ClientUrlService
     */
    public function option($modifier, $value = false)
    {
        if (is_array($modifier))
        {
            foreach ($modifier as $key => $value)
            {
                $this->option($key, $value);
            }

            return $this;
        }

        $this->_options[$modifier] = $value;
        return $this;
    }
}