<?php
/**
 * Created by PhpStorm.
 * User: Ian Moreno <ian.moreno@republisys.com>
 * Date: 9/29/17 11:27 AM 
 */

namespace Rzian\ClientUrl;

use Rzian\ClientUrl\Contracts\ClientUrlResponseContract;

class ClientUrlResponse implements ClientUrlResponseContract
{
    /**
     * cUrl response status code
     *            
     * @var int
     */    
    protected $_code;

    /**
     * cUrl response status
     *            
     * @var string
     */    
    protected $_status;

    /**
     * cUrl response error
     *            
     * @var string
     */    
    protected $_error;

    /**
     * cUrl response data after execute
     *            
     * @var array
     */    
    protected $_content = array();

    /**
     * Class constructor.
     *
     * @param array $content
     * @param array $error
     * @param string $status
     * @param int $code
     */
    public function __construct($content, $error, $status, $code)
    {
        $this->_code = $code;
        $this->_status = $status;
        $this->_error = $error;
        $this->_content = $content;
    }

    /**
     * Class magic getter for data collection.
     *
     * @param string $name
     * @return mixed
     */
    public function __get($name)
    {
        if (! array_key_exists($name, $this->_content))
        {
            return null; // safe return
        }

        return $this->_content[$name];
    }

    /**
     * Class magic setter for data collection.
     *
     * @param string $name
     * @param mixed $value
     * @return void
     */
    public function __set($name, $value)
    {
        trigger_error('Not allowed to set property value', E_USER_NOTICE);
    }

    /**
     * Class magic isset checker of data key
     *
     * @param string $name
     * @return bool
     */
    public function __isset($name)
    {
        return isset($this->_content[$name]);
    }

    /**
     * Class magic unset of data key and its value.
     *
     * @param string $name
     * @return bool
     */
    public function __unset($name)
    {
        trigger_error('Not allowed to unset property', E_USER_NOTICE);
    }

    /**
     * Retrieves content value via any key of int or string.
     *
     * @param int|string $key
     * @return mixed
     */ 
    public function get($key)
    {
        return $this->__get($key);
    }

    /**
     * Retrieve HTTP status.
     *
     * TODO: Need to standardized depending the api
     * @return string
     */    
    public function getStatus()
    {
        return $this->_status;
    }

    /**
     * Retrieve HTTP status code.
     *
     * TODO: Need to standardized depending the api
     * @return int
     */
    public function getStatusCode()
    {
        return (int)$this->_code;
    }

    /**
     * Validates error response.
     *
     * @return bool
     */
    public function isError()
    {
        return (int)$this->getStatusCode() >= 400;
    }

    /**
     * Alias of getStatusCode function.
     *
     * @return int|null
     */
    public function getErrorCode()
    {
        return $this->isError() ? $this->getStatusCode() : null;
    }

    /**
     * Retrieves error status.
     *
     * @return null|string
     */
    public function getErrorStatus()
    {
        return $this->isError() ? $this->getStatus() : null;
    }

    /**
     * Retrieves error message content.
     *
     * @return string|null
     */
    public function getErrorMessage()
    {
        return $this->isError() ? $this->error : null;
    }

    /**
     * Convert content to array values
     *
     * @return array
     */
    public function toArray()
    {
        return (array)$this->_content;
    }

    /**
     * Convert content to JSON string value.
     *
     * @return string
     */
    public function toJson()
    {
        return json_encode($this->_content);
    }
}