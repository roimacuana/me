<?php

namespace Roi\ControllerUrl;

use ReflectionMethod;

class Router
{
    const MOD_ROUTE_WEB = '@route';
    const MOD_ROUTE_API = '@apiroute';
    const ROUTE_PATTERN = '/%s (any|get|post|put|patch|delete|\[[a-z, ]+\]) ([\w\/\-\{\?\}]+)(?:\s+--name=([.\w]+)|)?(?:\s+--prefix=([._\w]+|\[[ .,\w]+\]))?(?:\s+--(with-no-prefix)|)?/i';

    /**
     * Route collector
     *
     * @var array $routes
     */
    protected $routes = array();

    /**
     * Route group collector
     *
     * @var array $group_routes
     */
    protected $group_routes = array();

    /**
     * The Constructor
     *
     * @param string $controller
     * @param bool $isAPIRoute
     */
    public function __construct($controller, $isAPIRoute = false)
    {
        $pattern = sprintf(self::ROUTE_PATTERN, $isAPIRoute ? self::MOD_ROUTE_API : self::MOD_ROUTE_WEB);
        $name = class_basename($controller);
        $methods = get_class_methods($controller);
        if ($parent = get_parent_class($controller))
        {
            $methods = array_diff($methods, get_class_methods($parent));
        }

        foreach($methods as $method)
        {
            $methodInstance = new ReflectionMethod($controller, $method);
            if (! $methodInstance->isPublic() || $methodInstance->isStatic() || ! preg_match($pattern, $methodInstance->getDocComment(), $result))
            {
                continue;
            }

            $action = sprintf('%s@%s', $name, $method);
            list($_, $verb, $route, $alias, $prefix, $flag) = array_pad($result, 6, false);
            $verbs = preg_split('/[ ,\[\]]/', strtolower($verb), -1, PREG_SPLIT_NO_EMPTY);
            if ($prefixes = $prefix ? preg_split('/[ ,\[\]]/', strtolower($prefix), -1, PREG_SPLIT_NO_EMPTY) : false)
            {
                foreach($prefixes as $prefix)
                {
                    $this->add($action, $route, $verbs, $alias, $prefix);
                }
            }

            if (($prefixes && $flag) || ! $prefixes)
            {
                $this->add($action, $route, $verbs, $alias);
            }
        }
    }

    /**
     * Collects route context
     *
     * @param string $controller
     * @param string $route
     * @param array $verbs
     * @param string|bool $alias
     * @param bool $prefix
     */
    protected function add($controller, $route, $verbs, $alias, $prefix = false)
    {
        $name = $alias && $prefix ? sprintf('%s.%s', $prefix, $alias) : $alias;
        $params = array($route, $controller);
        $method = last($verbs);
        if (sizeof($verbs) > 1)
        {
            $method = 'match';
            array_unshift($params, $verbs);
        }

        if ($prefix)
        {
            $this->group_routes[$prefix][] = (object)compact('method', 'params', 'name'); return;
        }
        $this->routes[] = (object)compact('method', 'params', 'name');
    }

    /**
     * Registering route to laravel routing container
     *
     * @param string $class
     */
    public function register($class)
    {
        if (sizeof($this->group_routes) > 0)
        {
            foreach ($this->group_routes as $prefix => $routes)
            {
                call_user_func(array($class, 'prefix'), $prefix)->group(function() use ($class, $routes) {
                    foreach ($routes as $route)
                    {
                        $router = call_user_func_array(array($class, $route->method), $route->params);
                        if ($route->name)
                        {
                            $router->name($route->name);
                        }
                    }
                });
            }
        }

        if (sizeof($this->routes) > 0)
        {
            foreach ($this->routes as $route)
            {
                $router = call_user_func_array(array($class, $route->method), $route->params);
                if ($route->name)
                {
                    $router->name($route->name);
                }
            }
        }
    }
}