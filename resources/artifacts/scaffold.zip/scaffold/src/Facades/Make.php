<?php
/**
 * Created by PhpStorm.
 * User: Ian Moreno <ian.moreno@republisys.com>
 * Date: 9/28/17 9:19 AM 
 */

namespace Rzian\Scaffold\Facades;

use Rzian\Scaffold\Router;
use Illuminate\Support\Facades\Facade;
use Route;

class Make extends Facade
{
    /**
     * Register routes for the given controller.
     *
     * @param string $controller
     */
    protected static function routes($controller)
    {
        $router = new Router($controller);

        $router->register(Route::class);
    }

    /**
     * Register api routes for the given controller.
     *
     * @param string $controller
     */
    protected static function routesAPI($controller)
    {
        $router = new Router($controller, true);

        $router->register(Route::class);
    }

    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'make';
    }
}