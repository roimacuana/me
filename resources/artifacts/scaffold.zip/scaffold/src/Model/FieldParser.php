<?php
namespace Roi\Scaffold\Model;

use ReflectionProperty as Property;
use Illuminate\Support\Facades\DB;

class FieldParser
{

    protected $model;

    protected $schema;

    /**
     * The constructor class.
     *
     * @param string $model
     */
    public function __construct($model)
    {
        $this->model = new $model;
        $this->schema = DB::connection()->getDoctrineSchemaManager();
    }

    /**
     * Retrieves table name of a model instance.
     *
     * @param bool $isWithPrefix
     * @return string
     */
    public function getTable($isWithPrefix = true)
    {
        if (! $isWithPrefix)
        {
            return $this->model->getTable();
        }

        return DB::getTablePrefix().$this->model->getTable();
    }

    /**
     * Retrieves the columns of a model instance.
     *
     * @return \Doctrine\DBAL\Schema\Column[]
     */
    public function getColumns()
    {
        return $this->schema->listTableColumns($this->getTable());
    }

    /**
     * Retrieves the foreign keys of a model instance
     *
     * @return \Doctrine\DBAL\Schema\ForeignKeyConstraint[]
     */
    public function getForeignKeys()
    {
        return $this->schema->listTableForeignKeys($this->getTable());
    }

    /**
     * Retrieves the property from protected model instance.
     *
     * @param string $name
     * @return mixed
     */
    public function getProperty($name)
    {
        $property = new Property(get_class($this->model), $name);
        $property->setAccessible(true);
        return $property->getValue($this->model);
    }

}
