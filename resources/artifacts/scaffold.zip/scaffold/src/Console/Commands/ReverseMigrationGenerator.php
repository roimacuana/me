<?php
/**
 * Created by PhpStorm.
 * User: Jason.Viado
 * Date: 10/13/17
 * Time: 3:24 PM
 */

namespace Rzian\Scaffold\Console\Commands;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class ReverseMigrationGenerator extends Generator {

    protected $signature = 'g:migration {table?} {--all : Generates all in database}';

    protected $description = 'Generate migration from database';
    /**
     * Execute the console command
     */
    public function handle(){
        if($this->argument('table')){
            $this->migration($this->argument('table'));
        }else if($this->option('all')){
            $schema = DB::connection()->getDoctrineSchemaManager();
            $tables = $schema->listTableNames();

            $tables = $this->arrange_tables($tables);

            foreach($tables as $data){
                    $this->migration($data,false);
            }




        }else{
            $this->error(sprintf(static::CUSTOM_ERROR, 'Argument false.'));
            $this->abort();
        }
    }

    /**
     * Function for migration
     * @param $table
     * @param bool $isAbort
     * @return bool
     */
    function migration($table, $isAbort = true){
        $db_prefix = DB::getTablePrefix();
        if($db_prefix){
            $table = substr($table, strlen($db_prefix));
        }
        if(! Schema::hasTable($table)){
            $this->error(static::ERROR_WRITE);
            if(! $isAbort)
                return false;
            else
                $this->abort();
        }
        $class = explode('_',$table);
        $file_name = [];
        foreach($class as $key => $data){
            $class[$key] = ucfirst(str_singular($data));
            $file_name[$key] = str_singular($data);
        }
        $class = implode('',$class);
        if(file_exists($path = base_path(str_replace('/', DIRECTORY_SEPARATOR, "database/migrations/". date('Y_m_d_his') ."_".implode('_',$file_name)."_table.php"))) &&
            ! $this->confirm(sprintf(static::ERROR_ASK_OVERWRITE, 'Migrating', $table), true)){
            if(! $isAbort)
                return false;
            else
                $this->abort();
        }
        $schema = DB::connection()->getDoctrineSchemaManager();
        $columns = $schema->listTableColumns($db_prefix.$table);
        $foreign = $schema->listTableForeignKeys($db_prefix.$table);
        $unique = $schema->listTableIndexes($db_prefix.$table);
        $output = $this->column_list($columns)." \n\t\t\t".$this->foreign_list($foreign,$db_prefix)." \n\t\t\t".$this->unique_list($unique,$db_prefix);
        $table = lcfirst($table);
        list($pattern, $replace) = $this->getOptions(compact('class', 'table', 'output'));
        $scaffold = $this->getScaffold('default').DIRECTORY_SEPARATOR.'migration';
        $content = preg_replace($pattern, $replace, file_get_contents($scaffold));
        if (! file_put_contents($path, $content)){
            $this->error(static::ERROR_WRITE);
            if(! $isAbort)
                return false;
            else
                $this->abort();
        }
        $this->info(sprintf(static::INFO_SUCCESS, 'Migrating', $table));
    }

    /**
     * Function for generating columns
     * @param $columns
     * @return string
     */
    function column_list($columns){
        $list = [];
        $i = 0;
        foreach($columns as $key => $data){
            $list[$i] = '$table';
            $type = $data->getType()->getName();
            if($length = $data->getLength()){
                $length = ",$length";
            }
            if($type == 'decimal'){
                $length = ",".$data->getPrecision().",".$data->getScale();
            }
            $list[$i] .= "->$type('$key'$length)";
            if($data->getUnsigned()){
                $list[$i] .= "->unsigned()";
            }
            if(!$data->getNotnull()){
                $list[$i] .= "->nullable()";
            }
            if($default = $data->getDefault()){
                $list[$i] .= "->default('$default')";
            }
            if($data->getComment()){
                $list[$i] .= "->comment('".$data->getComment()."')";
            }
            if($data->getAutoincrement() || $key == 'id'){
                if($type == 'integer'){
                    $list[$i] =  '$table'."->increments('$key')->unsigned()";
                }else{
                    $list[$i] =  '$table'."->$type('$key'$length)->primary()";
                }
            }
            $list[$i] .= ';';
            if($type == 'datetime'){
                if($key == 'created_at' || $key == 'updated_at'){
                    $list[$i] = '';
                }
            }
            $i++;
        }
        array_push($list,'$table'."->timestamp('created_at')->default(\\DB::raw('CURRENT_TIMESTAMP'));");
        array_push($list,'$table'."->timestamp('updated_at')->default(\\DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));");
        return implode("\n\t\t\t",$list);
    }

    /**
     * Function for generating foreign keys
     * @param $foreign
     * @param $prefix
     * @return string
     */
    function foreign_list($foreign,$prefix){
        $list = [];
        foreach($foreign as $key => $data){
            $list[$key] = '$table';
            $table = substr($data->getForeignTableName(), strlen($prefix));
            $list[$key] .= "->foreign('".$data->getLocalColumns()[0]."')->references('".$data->getForeignColumns()[0]."')->on('".$table."');";
        }
        return implode("\n\t\t\t",$list);
    }

    /**
     * Function for generating unique keys
     * @param $unique
     * @param $prefix
     * @return string
     */
    public function unique_list($unique,$prefix){
        $list = [];
        foreach($unique as $key => $data){
            if($data->isUnique() && !$data->isPrimary()){
                $list[$key] = '$table';
                $list[$key] .= "->unique('".$data->getColumns()[0]."');";
            }
        }
        return implode("\n\t\t\t",$list);
    }
    public function arrange_tables($tables){
        dd($tables);
    }
}