<?php
/**
 * Created by PhpStorm.
 * User: Ian Moreno <ian.moreno@republisys.com>
 * Date: 10/09/17 4:36 PM
 */

namespace Rzian\Scaffold\Console\Commands;

use Illuminate\Support\Facades\File;

class ScaffoldGenerator extends Generator
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'g:scaffold {name=default : The scaffold name to assign}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generates scaffold template';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if ($scaffold = $this->getScaffold($name = $this->argument('name'), false))
        {
            if (! $this->confirm(sprintf(static::ERROR_ASK_OVERWRITE, 'Scaffold', $name), true))
            {
                $this->abort();
            }

            if (! File::deleteDirectory($scaffold))
            {
                $this->error(static::ERROR_WRITE);
                $this->abort();
            }
        }

        @mkdir($scaffold = $this->getScaffoldPath($name), 0777, true);
        if(! File::copyDirectory($this->getOriginalScaffoldPath(), $scaffold))
        {
            $this->error(static::ERROR_WRITE);
            $this->abort();
        }

        $this->info(sprintf(static::INFO_SUCCESS, 'Scaffold', $name));
    }
}