<?php
/**
 * Created by PhpStorm.
 * User: Jason.Viado
 * Date: 10/18/17
 * Time: 10:53 AM
 */

namespace Rzian\Scaffold\Console\Commands;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class ReverseSeederGenerator extends Generator {

    protected $signature = 'g:seeder {table?} {--all : Generates all in database}';

    protected $description = 'Generate seeder from database';
    /**
     * Execute the console command
     */
    public function handle(){
        if($this->argument('table')){
            $this->seeding($this->argument('table'));
        }else if($this->option('all')){
            $schema = DB::connection()->getDoctrineSchemaManager();
            $tables = $schema->listTableNames();
            foreach($tables as $data){
                $this->seeding($data,false);
            }
        }else{
            $this->error(sprintf(static::CUSTOM_ERROR, 'Argument false.'));
            $this->abort();
        }
    }

    /**
     * Function for seeding
     * @param $table
     * @param bool $isAbort
     * @return bool
     */
    function seeding($table, $isAbort = true){
        $db_prefix = DB::getTablePrefix();
        if($db_prefix){
            $table = substr($table, strlen($db_prefix));
        }
        if(! Schema::hasTable($table)){
            $this->error(static::ERROR_WRITE);
            if(! $isAbort)
                return false;
            else
                $this->abort();
        }
        $class = explode('_',$table);
        foreach($class as $key => $data){
            $class[$key] = ucfirst(str_singular($data));
        }
        $class = implode('',$class);
        if(file_exists($path = base_path(str_replace('/', DIRECTORY_SEPARATOR,'database/seeds/'.$class.'TableSeeder.php'))) &&
            ! $this->confirm(sprintf(static::ERROR_ASK_OVERWRITE, 'Seeding', $table), true)){
            if(! $isAbort)
                return false;
            else
                $this->abort();
        }
        $query = DB::table($table)->get();
        $output = $this->create($query);
        list($pattern, $replace) = $this->getOptions(compact('output', 'table', 'class'));
        $scaffold = $this->getScaffold('default').DIRECTORY_SEPARATOR.'seed';
        $content = preg_replace($pattern, $replace, file_get_contents($scaffold));
        if (! file_put_contents($path, $content)){
            $this->error(static::ERROR_WRITE);
            if(! $isAbort)
                return false;
            else
                $this->abort();
        }
        $this->info(sprintf(static::INFO_SUCCESS, 'Seeding', $table));
    }

    /**
     * Function for generating data
     * @param $query
     * @return string
     */
    function create($query){
        $list = [];
        $i = 0;
        foreach($query as $data){
            $form = '';
            foreach($data as $key => $value){
                $form .= "\n \t \t \t \t " . "'$key' => '$value',";
            }
            $list[$i] = "[$form\n\t\t\t]";
            $i++;
        }
        return implode(",\n \t \t \t",$list);
    }
}