<?php
/**
 * Created by PhpStorm.
 * User: Ian Moreno <ian.moreno@republisys.com>
 * Date: 10/11/17 7:32 AM
 */

namespace Rzian\Scaffold\Console\Commands;

use Illuminate\Console\Command;
use Rzian\Scaffold\ModelReflector;

abstract class Generator extends Command
{
    /**
     * Subject delimiter pattern
     */
    const DELIMITER = '/\!\@\{%s\}\^/';

    /**
     * Information success message
     */
    const INFO_SUCCESS = "...%s '%s' generated successfully!";

    /**
     * Error message for write permission
     */
    const ERROR_WRITE = "Error: Unable to write to your application resource path. Please set the correct permission!";

    /**
     * Error message for file existence but ask to overwrite
     */
    const ERROR_ASK_OVERWRITE = "%s '%s' is already exists. Do you wish to overwrite?";

    /**
     * Error message undefined context
     */
    const ERROR_UNDEFINED = "Error: Undefined %s '%s'.";

    /**
     * The constructor class.
     */
    public function __construct()
    {
        parent::__construct();

        @ini_set('timezone', config('app.timezone'));
    }

    /**
     * Validates the existence of a model and return its namespace.
     *
     * @param $model
     * @param bool $isAbort
     * @return bool|string
     */
    protected function getModel($model, $isAbort = true)
    {
        if (! class_exists($class = '\\App\\Models\\'.$model))
        {
            if(! class_exists($class = '\\App\\'.$model))
            {
                if(! $isAbort)
                {
                    return false;
                }
                $this->error(sprintf(static::ERROR_UNDEFINED, 'model', $model));
                $this->abort();
            }
        }
        return substr($class, 1);
    }

    /**
     * Retrieves model instance, reflection, and schema.
     *
     * @param $model
     * @return ModelReflector
     */
    protected function getModelInstance($model)
    {
        return new ModelReflector($model);
    }

    /**
     * Aborts the command session.
     *
     * @param string $message
     */
    protected function abort($message = "...aborted\n")
    {
        exit($message);
    }

    /**
     * Retrieves the original scaffold path.
     *
     * @return string
     */
    protected function getOriginalScaffoldPath()
    {
        return base_path(str_replace('/', DIRECTORY_SEPARATOR, 'vendor/rzian/scaffold/scaffold'));
    }

    /**
     * Retrieves the resource scaffold path.
     *
     * @param string $name
     * @return string
     */
    protected function getScaffoldPath($name = 'default')
    {
        return resource_path('scaffold').DIRECTORY_SEPARATOR.$name;
    }

    /**
     * Retrieves resource scaffold path.
     *
     * @param string $name
     * @param bool $isGetOriginal
     * @return bool|string
     */
    protected function getScaffold($name = 'default', $isGetOriginal = true)
    {
        if (file_exists($path = $this->getScaffoldPath($name)))
        {
            return $path;
        }

        if ($isGetOriginal)
        {
            if ($name != 'default')
            {
                $this->error(sprintf(static::ERROR_UNDEFINED, 'scaffold', $name));
                $this->abort();
            }
            return $this->getOriginalScaffoldPath();
        }
        return false;
    }

    /**
     * Retrieves the option params with delimited key pattern.
     *
     * @param array $options
     * @return array
     */
    protected function getOptions($options = array())
    {
        $keys = $this->getDelimiter(array('developer', 'datetime'));
        $values = array(
            env('APP_DEV', gethostname()),
            date('m/d/y h:i A')
        );
        if (sizeof($options) > 0)
        {
            foreach($options as $key => $value)
            {
                $keys[] = $this->getDelimiter($key);
                $values[] = $value;
            }
        }

        return array($keys, $values);
    }

    /**
     * Retrieves delimited key name
     *
     * @param string|array $name
     * @return string|array
     */
    protected function getDelimiter($name)
    {
        if (is_array($name))
        {
            $delimiters = array();
            foreach($name as $value) 
            {
                $delimiters[] = $this->getDelimiter($value);
            }

            return $delimiters;
        }

        return sprintf(self::DELIMITER, strtoupper($name));
    }

    /**
     * Generates file.
     *
     * @param string $path
     * @param string $content
     */
    protected function generate($path, $content)
    {
        if (! file_put_contents($path, $content))
        {
            $this->error(static::ERROR_WRITE);
            $this->abort();
        }
    }
}