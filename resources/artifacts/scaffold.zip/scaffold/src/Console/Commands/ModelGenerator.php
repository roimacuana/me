<?php
/**
 * Created by PhpStorm.
 * User: Jason.Viado
 * Date: 10/19/17
 * Time: 7:49 AM
 */
namespace Rzian\Scaffold\Console\Commands;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class ModelGenerator extends Generator{

    protected $signature = 'g:model {table?} {--path=} {--all : Generates all in database}';

    protected $description = 'Generates model from database';

    /**
     * Execute the console command
     */
    public function handle(){
        if($this->argument('table')){
            $this->model($this->argument('table'),$this->option('path'));
        }else if($this->option('all')){
            $tables = DB::select('SHOW TABLES');
            foreach($tables as $data){
                foreach ($data as $value){
                    $this->model($value,$this->option('path'),false);
                }
            }
        }else{
            $this->error(sprintf(static::CUSTOM_ERROR, 'Argument false.'));
            $this->abort();
        }
    }

    /**
     * Function for generating model
     * @param $table
     * @param string $name_space
     * @param bool $isAbort
     * @return bool
     */
    function model($table,$name_space = '',$isAbort = true){
        $name_space = ucfirst(str_replace("\\","/",$name_space));
        $db_prefix = DB::getTablePrefix();
        $table = substr($table, strlen($db_prefix));
        if(! Schema::hasTable($table)){
            $this->error(static::ERROR_WRITE);
            if(! $isAbort)
                return false;
            else
                $this->abort();
            $this->abort();
        }
        $class = explode('_',$table);
        foreach($class as $key => $data){
            $class[$key] = ucfirst(str_singular($data));
        }
        $class = implode('',$class);
        if(file_exists($path = app_path(str_replace('/', DIRECTORY_SEPARATOR, "$name_space/".$class.".php"))) &&
            ! $this->confirm(sprintf(static::ERROR_ASK_OVERWRITE, 'Model', $table), true)){
            if(! $isAbort)
                return false;
            else
                $this->abort();
        }
        $schema = DB::connection()->getDoctrineSchemaManager();
        $columns = $schema->listTableColumns($db_prefix.$table);
        $foreign = $schema->listTableForeignKeys($db_prefix.$table);
        $fillable = $this->fillable($columns);
        $relationship = $this->relationship($foreign,$db_prefix);
        $rules = $this->rules($columns);

        if($name_space)
            $name_space = "App\\".$name_space;
        else
            $name_space = "App";
        list($pattern, $replace) = $this->getOptions(compact('class', 'table', 'fillable' , 'name_space','relationship','rules'));
        $scaffold = $this->getScaffold('default').DIRECTORY_SEPARATOR.'model';
        $content = preg_replace($pattern, $replace, file_get_contents($scaffold));
        if (! file_put_contents($path, $content)){
            $this->error(static::ERROR_WRITE);
            if(! $isAbort)
                return false;
            else
                $this->abort();
            $this->abort();
        }
        $this->info(sprintf(static::INFO_SUCCESS, 'Model', $class));
    }

    /**
     * Function for generating fillable columns
     * @param $columns
     * @return string
     */
    function fillable($columns){
        $list = '';
        foreach($columns as $key => $data){
            if($data->getNotnull() && $key != 'id')
                $list .= "'$key',";
        }
        return $list;
    }

    /**
     * Function for generating eloquent relationship
     * @param $keys
     * @param $db_prefix
     * @return string
     */
    function relationship($foreign,$db_prefix){
        $list = [];
        foreach($foreign as $key => $data){
            $list[$key] = '$table';
            $table = substr($data->getForeignTableName(), strlen($db_prefix));
            $function = ucfirst($table);
            $class = $this->getModel(ucfirst(str_singular($table)));
            $list[$key] = "/** \n \t *  Relationship for ".$function." \n\t */ \n \t public function $table(){\n \t \t ".'$this->belongsTo('."'".$class."'); \n\t}";
        }
        return implode("\n \t",$list);
    }

    /**
     * Function for generating validation rules
     * @param $columns
     * @return string
     */
    function rules($columns){
        $list = [];
        $i = 0;
        foreach($columns as $key => $data){
            $rules = '';
            if($data->getNotnull() && $key != 'id')
                $rules = 'required';
            if($rules)
                $list[] = "'$key' => '$rules'";
            $i++;
        }
        return implode(",\n \t \t",$list);
    }

}