<?php
/**
 * Created by PhpStorm.
 * User: Ian Moreno <ian.moreno@republisys.com>
 * Date: 10/09/17 4:38 PM
 */

namespace Rzian\Scaffold\Console\Commands;

class ViewGenerator extends Generator
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'g:view {model : The model name for generating view} {--scaffold=default : The scaffold name to be used}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generates view for a model';

    /**
     * @var array
     */
    private $inputs = [
        'string' => '<input type="text" %s/>',
        'text' => '<textarea %s></textarea>',
        'datetime' => '<input type="datetime" %s/>',
    ];

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $model = $this->getModel($this->argument('model'));
        $basename = basename($model);
        $name = lcfirst($basename);
        if (! file_exists($path = resource_path('views').DIRECTORY_SEPARATOR.$name))
        {
            @mkdir($path, 0777);
        }

        $this->generateViewForm(
            $this->confirmPath($path, 'form'),
            $scaffold = $this->getScaffold($this->option('scaffold')),
            $instance = $this->getModelInstance($model),
            $route = str_plural($name)
        );

        $this->generateViewList(
            $this->confirmPath($path, 'index'),
            $scaffold,
            $instance,
            $route,
            $basename,
            sprintf('%s.form', $name)
        );

        $this->info(sprintf(static::INFO_SUCCESS, 'View', $name));
    }

    /**
     * Generates view form blade template
     *
     * @param $path
     * @param $scaffold
     * @param $instance
     * @param $route
     */
    protected function generateViewForm($path, $scaffold, $instance, $route)
    {
        $field = file_get_contents($scaffold.DIRECTORY_SEPARATOR.'view.form.field');
        if (! preg_match('/<input (.+)>/', $field, $result))
        {
            $this->error('Error: Cannot find HTML tag input.');
            $this->abort();
        }

        list($pattern, $attributes) = $result;
        $delimiters = $this->getDelimiter(['label', 'name']);
        $fields = '';
        foreach($instance->getColumns() as $name => $column)
        {
            $type = $column->getType()->getName();
            $input = array_key_exists($type, $this->inputs) ? $this->inputs[$type] : $this->inputs['string'];
            $fields .= preg_replace(
                $delimiters,
                [$this->getLabel($name), $name],
                str_replace($pattern, sprintf($input, $attributes), $field)
            );
        }

        list($pattern, $replacement) = $this->getOptions(compact('route', 'fields'));
        $this->generate($path, preg_replace($pattern, $replacement, file_get_contents($scaffold.DIRECTORY_SEPARATOR.'view.form')));
    }

    /**
     * Generates view list blade template
     *
     * @param $path
     * @param $scaffold
     * @param $instance
     * @param $route
     * @param $title
     * @param $form
     */
    protected function generateViewList($path, $scaffold, $instance, $route, $title, $form)
    {
        $labels = array($instance->getProperty('primaryKey'));
        if ($instance->getProperty('timestamps'))
        {
            $labels[] = 'created_at';
        }

        $column = file_get_contents($scaffold.DIRECTORY_SEPARATOR.'view.index.column');
        $delimiter = $this->getDelimiter(['label', 'name']);
        $columns = '';
        foreach ($labels as $name)
        {
            $columns .= preg_replace(
                $delimiter,
                [$this->getLabel($name), $name],
                $column);
        }
        list($pattern, $replacement) = $this->getOptions(compact('route', 'title', 'form', 'columns'));
        $this->generate($path, preg_replace($pattern, $replacement, file_get_contents($scaffold.DIRECTORY_SEPARATOR.'view.index')));
    }

    /**
     * Parses column label name
     *
     * @param $name
     * @return string
     */
    protected function getLabel($name)
    {
        return ucwords(str_replace('_', ' ', $name));   
    }

    /**
     * Confirms view path
     *
     * @param $path
     * @param $name
     * @return string
     */
    protected function confirmPath($path, $name) 
    {
        $name .= '.blade.php';
        $path .= DIRECTORY_SEPARATOR.$name;
        if(file_exists($path) && ! $this->confirm(sprintf(static::ERROR_ASK_OVERWRITE, 'View', $name), true))
        {
            $this->abort();
        }

        return $path;
    }
}