<?php
/**
 * Created by PhpStorm.
 * User: Ian Moreno <ian.moreno@republisys.com>
 * Date: 10/09/17 3:01 PM
 */

namespace Rzian\Scaffold\Console\Commands;

class ControllerGenerator extends Generator
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'g:controller {model : The model name for generating controller} {--scaffold=default : The scaffold name to be used}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generates controller for a model';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $namespace = $this->getModel($this->argument('model'));
        $model = basename($namespace);
        $controller = sprintf('%sController', $model);
        $path = app_path(str_replace('/', DIRECTORY_SEPARATOR, "Http/Controllers/{$controller}.php"));
        if(file_exists($path) && ! $this->confirm(sprintf(static::ERROR_ASK_OVERWRITE, 'Controller', $controller), true))
        {
            $this->abort();
        }

        $var = lcfirst($model);
        $route = str_plural($var);
        list($pattern, $replace) = $this->getOptions(compact('namespace', 'model', 'route', 'var'));
        $scaffold = $this->getScaffold($this->option('scaffold')).DIRECTORY_SEPARATOR.'controller';

        $this->generate($path, preg_replace($pattern, $replace, file_get_contents($scaffold)));
        $this->info(sprintf(static::INFO_SUCCESS, 'Controller', $controller));
    }
}