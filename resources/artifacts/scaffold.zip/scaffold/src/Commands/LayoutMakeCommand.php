<?php
namespace Roi\Scaffold\Commands;

use Illuminate\Console\Command;
use Illuminate\Container\Container;
use Illuminate\Filesystem\Filesystem;

use Roi\Scaffold\Migration\NameParser;

use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class LayoutMakeCommand extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'generate:angular';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create a angular structure';
    /**
     * The filesystem instance.
     *
     * @var Filesystem
     */
    protected $files;
    /**
     * Meta information for the requested migration.
     *
     * @var array
     */
    protected $meta;
    /**
     * @var Composer
     */
    private $composer;


    /**
     * Create a new command instance.
     *
     * @param Filesystem $files
     */
    public function __construct(Filesystem $files)
    {
        parent::__construct();
        $this->files = $files;
        $this->composer = app()['composer'];
    }


    /**
     * Alias for the fire method.
     *
     * In Laravel 5.5 the fire() method has been renamed to handle().
     * This alias provides support for both Laravel 5.4 and 5.5.
     */
    public function handle()
    {
        $this->fire();
    }
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function fire()
    {
        $this->meta = (new NameParser)->parse($this->argument('app'));
        $this->makeAngular();
    }
    /**
     * Get the application namespace.
     *
     * @return string
     */
    protected function getAppNamespace()
    {
        return Container::getInstance()->getNamespace();
    }
    /**
     * Generate the desired migration.
     */
    protected function makeAngular()
    {
        $this->makeApp();
        $this->makeAng();
        $this->makeAdmin();
        $this->makeDefault();

        $this->makeVendor();
        $this->info('vendors created successfully.');
    }

    protected function makeAdmin(){

        if ($this->files->exists($path = $this->getAdminPath())) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->compileAdminStub());
        $this->info('admin blade created successfully.');
        $this->composer->dumpAutoloads();

    }

    protected function getAdminPath()
    {
        return base_path() . '/resources/views/layouts/admin.blade.php';
    }

    protected function compileAdminStub()
    {
        $stub = $this->files->get(__DIR__ . '/../Stubs/Layout/admin.stub');
        return $stub;
    }


    protected function makeAng(){

        if ($this->files->exists($path = $this->getAngularPath())) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->compileAngularStub());
        $this->info('angular blade created successfully.');
        $this->composer->dumpAutoloads();

    }

    protected function getAngularPath()
    {
        return base_path() . '/resources/views/components/angular.blade.php';
    }

    protected function compileAngularStub()
    {
        $stub = $this->files->get(__DIR__ . '/../Stubs/Layout/angular.stub');
        $this->getAppName($stub);
        return $stub;
    }

    protected function makeApp(){

        if ($this->files->exists($path = $this->getAppPath())) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->compileAppStub());
        $this->info('app blade created successfully.');
        $this->composer->dumpAutoloads();

    }

    protected function getAppPath()
    {
        return base_path() . '/resources/views/app.blade.php';
    }

    protected function compileAppStub()
    {
        $stub = $this->files->get(__DIR__ . '/../Stubs/Layout/app.stub');
        $this->getAppName($stub);
        return $stub;
    }

    protected function makeDefault(){

        if ($this->files->exists($path = $this->getDefaultPath())) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->compileDefaultStub());
        $this->info('default blade created successfully.');
        $this->composer->dumpAutoloads();

    }

    protected function getDefaultPath()
    {
        return base_path() . '/resources/views/layouts/default.blade.php';
    }

    protected function compileDefaultStub()
    {
        $stub = $this->files->get(__DIR__ . '/../Stubs/Layout/default.stub');
        return $stub;
    }

    protected function makeVendor(){

        $this->makeAngularjs();
        $this->makeBootstrapcss();
        $this->makeBootstrapjs();
        $this->makeConfirmcss();
        $this->makeConfirmjs();
        $this->makeJquery();
    }

    /*VENDORS*/

    protected function makeAngularjs(){
        if ($this->files->exists($path = base_path() . '/public/vendor/node_modules/angular/angular.min.js')) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->files->get(__DIR__ . '/../Stubs/Vendor/angularjs.stub'));
        $this->composer->dumpAutoloads();
    }

    protected function makeBootstrapcss(){
        if ($this->files->exists($path = base_path() . '/public/vendor/node_modules/bootstrap/bootstrap.min.css')) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->files->get(__DIR__ . '/../Stubs/Vendor/bootstrapcss.stub'));
        $this->composer->dumpAutoloads();
    }

    protected function makeBootstrapjs(){
        if ($this->files->exists($path = base_path() . '/public/vendor/node_modules/bootstrap/bootstrap.min.js')) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->files->get(__DIR__ . '/../Stubs/Vendor/bootstrapjs.stub'));
        $this->composer->dumpAutoloads();
    }

    protected function makeConfirmcss(){
        if ($this->files->exists($path = base_path() . '/public/vendor/node_modules/angular/angular-confirm.min.css')) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->files->get(__DIR__ . '/../Stubs/Vendor/confirmcss.stub'));
        $this->composer->dumpAutoloads();
    }

    protected function makeConfirmjs(){
        if ($this->files->exists($path = base_path() . '/public/vendor/node_modules/angular/angular-confirm.min.js')) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->files->get(__DIR__ . '/../Stubs/Vendor/confirmjs.stub'));
        $this->composer->dumpAutoloads();
    }

    protected function makeJquery(){
        if ($this->files->exists($path = base_path() . '/public/vendor/node_modules/jquery/jquery.min.js')) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->files->get(__DIR__ . '/../Stubs/Vendor/jqueryjs.stub'));
        $this->composer->dumpAutoloads();
    }

    protected function getAppName(&$stub)
    {
        $stub = str_replace('{{app}}', $this->argument('app'), $stub);
        return $stub;
    }

    /**
     * Build the directory for the class if necessary.
     *
     * @param  string $path
     * @return string
     */
    protected function makeDirectory($path)
    {
        if (!$this->files->isDirectory(dirname($path))) {
            $this->files->makeDirectory(dirname($path), 0777, true, true);
        }
    }

    /**
     * Get the console command arguments.
     *
     * @return array
     */
    protected function getArguments()
    {
        return [
            ['app', InputArgument::REQUIRED, 'The name of the app'],
        ];
    }

}