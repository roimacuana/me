<?php
namespace Roi\Scaffold\Commands;

use Illuminate\Console\Command;
use Illuminate\Container\Container;
use Illuminate\Filesystem\Filesystem;

use Roi\Scaffold\Migration\NameParser;

use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class ControllerMakeCommand extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'generate:controller';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create a new controller class';
    /**
     * The filesystem instance.
     *
     * @var Filesystem
     */
    protected $files;
    /**
     * Meta information for the requested migration.
     *
     * @var array
     */
    protected $meta;
    /**
     * @var Composer
     */
    private $composer;
    /**
     * Create a new command instance.
     *
     * @param Filesystem $files
     * @param Composer $composer
     */
    public function __construct(Filesystem $files)
    {
        parent::__construct();
        $this->files = $files;
        $this->composer = app()['composer'];
    }
    /**
     * Alias for the fire method.
     *
     * In Laravel 5.5 the fire() method has been renamed to handle().
     * This alias provides support for both Laravel 5.4 and 5.5.
     */
    public function handle()
    {
        $this->fire();
    }
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function fire()
    {
        $this->meta = (new NameParser)->parse($this->argument('name'));
        $this->makeController();
        $this->makeRoute();
    }
    /**
     * Get the application namespace.
     *
     * @return string
     */
    protected function getAppNamespace()
    {
        return Container::getInstance()->getNamespace();
    }
    /**
     * Generate the desired migration.
     */
    protected function makeController()
    {
        $name = $this->argument('name');
        if ($this->files->exists($path = $this->getControllerPath($name))) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->compileControllerStub());
        $this->info('Controller created successfully.');
        $this->composer->dumpAutoloads();
    }
    /**
     * Generate the desired migration.
     */
    protected function makeRoute()
    {
        file_put_contents(
            base_path('routes/web.php'),
            $this->compileRouteStub(),
            FILE_APPEND
        );
        $this->info('Route created successfully.');
        $this->composer->dumpAutoloads();
    }
    /**
     * Build the directory for the class if necessary.
     *
     * @param  string $path
     * @return string
     */
    protected function makeDirectory($path)
    {
        if (!$this->files->isDirectory(dirname($path))) {
            $this->files->makeDirectory(dirname($path), 0777, true, true);
        }
    }
    /**
     * Get the destination class path.
     *
     * @param  string $name
     * @return string
     */
    protected function getControllerPath($name)
    {
        $name = str_replace($this->getAppNamespace(), '', $name);
        return $this->laravel['path'] . '/Http/Controllers/' . $name . '.php';
    }
    /**
     * Compile the migration stub.
     *
     * @return string
     */
    protected function compileControllerStub()
    {

        $stub = $this->files->get(__DIR__ . '/../Stubs/controller.stub');
        $this->replaceClassName($stub);
        $this->replaceModelName($stub);
        $this->replaceRouteName($stub);
        $this->replaceVariableName($stub);

        return $stub;
    }

    protected function compileRouteStub()
    {
        $stub = $this->files->get(__DIR__ . '/../Stubs/route.stub');
        $this->replaceClassName($stub);
        return $stub;
    }

    /**
     * Replace the class name in the stub.
     *
     * @param  string $stub
     * @return $this
     */
    protected function replaceClassName(&$stub)
    {
        $className = ucwords(camel_case($this->argument('name')));
        $stub = str_replace('{{class}}', $className, $stub);
        return $this;
    }

    /**
     * Get the class name for the Eloquent model generator.
     *
     * @return string
     * @param string $stub
     */
    protected function replaceModelName(&$stub)
    {
        $model = ucwords(str_singular(($this->argument('name'))));
        $stub = str_replace('{{model}}', str_replace('Controller','',$model), $stub);
        return $this;
    }

    /**
     * Get the class name for the Eloquent model generator.
     *
     * @return string
     * @param string $stub
     */
    protected function replaceRouteName(&$stub)
    {
        $route = str_plural(strtolower(str_replace('Controller','',$this->argument('name'))));
        $stub = str_replace('{{route}}', $route, $stub);
        return $this;
    }

    /**
     * Get the class name for the Eloquent model generator.
     *
     * @return string
     * @param string $stub
     */
    protected function replaceVariableName(&$stub)
    {
        $route = str_singular(strtolower(str_replace('Controller','',$this->argument('name'))));
        $stub = str_replace('{{variable}}', $route, $stub);
        return $this;
    }

    /**
     * Get the console command arguments.
     *
     * @return array
     */
    protected function getArguments()
    {
        return [
            ['name', InputArgument::REQUIRED, 'The name of the migration'],
        ];
    }

}