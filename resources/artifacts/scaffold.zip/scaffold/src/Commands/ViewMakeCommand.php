<?php
namespace Roi\Scaffold\Commands;

use Illuminate\Console\Command;
use Illuminate\Container\Container;
use Illuminate\Filesystem\Filesystem;

use Roi\Scaffold\Model\FieldParser;
use Roi\Scaffold\Migration\NameParser;

use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class ViewMakeCommand extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'generate:view';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create a new view class';
    /**
     * The filesystem instance.
     *
     * @var Filesystem
     */
    protected $files;
    /**
     * Meta information for the requested migration.
     *
     * @var array
     */
    protected $meta;
    /**
     * @var Composer
     */
    private $composer;

    /**
     * @var array
     */
    private $inputs = [
        'string' => '<input type="text" %s/>',
        'text' => '<textarea %s></textarea>',
        'datetime' => '<input type="datetime" %s/>',
    ];

    /**
     * Subject delimiter pattern
     */
    const DELIMITER = '/\!\@\{%s\}\^/';
    const ERROR_WRITE = "Error: Unable to write to your application resource path. Please set the correct permission!";

    /**
     * Aborts the command session.
     *
     * @param string $message
     */
    protected function abort($message = "...aborted\n")
    {
        exit($message);
    }

    /**
     * Create a new command instance.
     *
     * @param Filesystem $files
     * @param Composer $composer
     */
    public function __construct(Filesystem $files)
    {
        parent::__construct();
        $this->files = $files;
        $this->composer = app()['composer'];
    }


    /**
     * Alias for the fire method.
     *
     * In Laravel 5.5 the fire() method has been renamed to handle().
     * This alias provides support for both Laravel 5.4 and 5.5.
     */
    public function handle()
    {
        $this->fire();
    }
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function fire()
    {
        $this->meta = (new NameParser)->parse($this->argument('model'));
        $this->makeView();
    }
    /**
     * Get the application namespace.
     *
     * @return string
     */
    protected function getAppNamespace()
    {
        return Container::getInstance()->getNamespace();
    }
    /**
     * Generate the desired migration.
     */
    protected function makeView()
    {
        $this->makeIndex();
        $this->makeForm();
    }

    protected function makeIndex(){
        $name = $this->argument('model');
        if ($this->files->exists($path = $this->getViewPath($name))) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->compileViewStub());
        $this->info('Index created successfully.');
        $this->composer->dumpAutoloads();
    }

    protected function makeForm(){
        $name = $this->argument('model');
        file_put_contents(
            base_path() . '/resources/views/'.str_plural(strtolower($name)).'/'.'form.blade.php',
            $this->compileFormStub()
        );

        $stub = $this->files->get(__DIR__ . '/../Stubs/View/form.stub');
        $this->replaceFieldName($stub);


        $this->info('Form created successfully.');
        $this->composer->dumpAutoloads();
    }

    /**
     * Build the directory for the class if necessary.
     *
     * @param  string $path
     * @return string
     */
    protected function makeDirectory($path)
    {
        if (!$this->files->isDirectory(dirname($path))) {
            $this->files->makeDirectory(dirname($path), 0777, true, true);
        }
    }
    /**
     * Get the destination class path.
     *
     * @param  string $name
     * @return string
     */
    protected function getViewPath($name)
    {
        $name = str_replace($this->getAppNamespace(), '', $name);
        return base_path() . '/resources/views/'.str_plural(strtolower($name)).'/'.'index.blade.php';
    }
    /**
     * Compile the migration stub.
     *
     * @return string
     */
    protected function compileViewStub()
    {
        $stub = $this->files->get(__DIR__ . '/../Stubs/View/index.stub');
        $this->replaceRouteName($stub);
        return $stub;
    }

    /**
     * Compile the migration stub.
     *
     * @return string
     */
    protected function compileFormStub()
    {

        $stub = $this->files->get(__DIR__ . '/../Stubs/View/form.stub');
        $this->replaceRouteName($stub);

        return $stub;
    }

    /**
     * Retrieves model instance, reflection, and schema.
     *
     * @param $model
     * @return ModelReflector
     */
    protected function getModelInstance($model)
    {
        return new FieldParser($model);
    }

    protected function replaceFieldName(&$stub){

        $model = $this->getModel($this->argument('model'));
        $instance = $this->getModelInstance($model);

        $field = $this->files->get(__DIR__ . '/../Stubs/View/form.field.stub');
        if (! preg_match('/<input (.+)>/', $field, $result))
        {
            $this->error('Error: Cannot find HTML tag input.');
            $this->abort();
        }

        list($pattern, $attributes) = $result;
        $delimiters = $this->getDelimiter(['label', 'name']);
        $fields = '';
        foreach($instance->getColumns() as $name => $column)
        {
            $type = $column->getType()->getName();
            $input = array_key_exists($type, $this->inputs) ? $this->inputs[$type] : $this->inputs['string'];
            $fields .= preg_replace(
                $delimiters,
                [$this->getLabel($name), $name],
                str_replace($pattern, sprintf($input, $attributes), $field)
            );
        }

        $path = base_path() . '/resources/views/'.str_plural(strtolower($this->argument('model'))).'/'.'form.blade.php';
        list($pattern, $replacement) = $this->getOptions(compact('route', 'fields'));
        $this->generate($path, preg_replace($pattern, $replacement, $stub));

    }

    /**
     * Generates file.
     *
     * @param string $path
     * @param string $content
     */
    protected function generate($path, $content)
    {
        if (! file_put_contents($path, $content))
        {
            $this->error(static::ERROR_WRITE);
            $this->abort();
        }
    }

    /**
     * Parses column label name
     *
     * @param $name
     * @return string
     */
    protected function getLabel($name)
    {
        return ucwords(str_replace('_', ' ', $name));
    }

    /**
     * Retrieves delimited key name
     *
     * @param string|array $name
     * @return string|array
     */
    protected function getDelimiter($name)
    {
        if (is_array($name))
        {
            $delimiters = array();
            foreach($name as $value)
            {
                $delimiters[] = $this->getDelimiter($value);
            }

            return $delimiters;
        }

        return sprintf(self::DELIMITER, strtoupper($name));
    }

    /**
     * Validates the existence of a model and return its namespace.
     *
     * @param $model
     * @param bool $isAbort
     * @return bool|string
     */
    protected function getModel($model, $isAbort = true)
    {
        if (! class_exists($class = '\\App\\Models\\'.$model))
        {
            if(! class_exists($class = '\\App\\'.$model))
            {
                if(! $isAbort)
                {
                    return false;
                }
                $this->error(sprintf(static::ERROR_UNDEFINED, 'model', $model));
                $this->abort();
            }
        }
        return substr($class, 1);
    }

    /**
     * Get the class name for the Eloquent model generator.
     *
     * @return string
     * @param string $stub
     */
    protected function replaceRouteName(&$stub)
    {
        $route = str_plural(strtolower(str_replace('Controller','',$this->argument('model'))));
        $stub = str_replace('{{route}}', $route, $stub);
        return $this;
    }

    /**
     * Retrieves the option params with delimited key pattern.
     *
     * @param array $options
     * @return array
     */
    protected function getOptions($options = array())
    {
        $keys = $this->getDelimiter(array('developer', 'datetime'));
        $values = array(
            env('APP_DEV', gethostname()),
            date('m/d/y h:i A')
        );
        if (sizeof($options) > 0)
        {
            foreach($options as $key => $value)
            {
                $keys[] = $this->getDelimiter($key);
                $values[] = $value;
            }
        }

        return array($keys, $values);
    }

    /**
     * Get the console command arguments.
     *
     * @return array
     */
    protected function getArguments()
    {
        return [
            ['model', InputArgument::REQUIRED, 'The name of the model'],
        ];
    }

}