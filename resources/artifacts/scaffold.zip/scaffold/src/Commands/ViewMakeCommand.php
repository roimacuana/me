<?php
namespace Roi\Scaffold\Commands;

use Illuminate\Console\Command;
use Illuminate\Container\Container;
use Illuminate\Filesystem\Filesystem;

use Roi\Scaffold\Migration\NameParser;

use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class ViewMakeCommand extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'generate:view';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create a new view class';
    /**
     * The filesystem instance.
     *
     * @var Filesystem
     */
    protected $files;
    /**
     * Meta information for the requested migration.
     *
     * @var array
     */
    protected $meta;
    /**
     * @var Composer
     */
    private $composer;
    /**
     * Create a new command instance.
     *
     * @param Filesystem $files
     * @param Composer $composer
     */
    public function __construct(Filesystem $files)
    {
        parent::__construct();
        $this->files = $files;
        $this->composer = app()['composer'];
    }
    /**
     * Alias for the fire method.
     *
     * In Laravel 5.5 the fire() method has been renamed to handle().
     * This alias provides support for both Laravel 5.4 and 5.5.
     */
    public function handle()
    {
        $this->fire();
    }
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function fire()
    {
        $this->meta = (new NameParser)->parse($this->argument('model'));
        $this->makeView();
    }
    /**
     * Get the application namespace.
     *
     * @return string
     */
    protected function getAppNamespace()
    {
        return Container::getInstance()->getNamespace();
    }
    /**
     * Generate the desired migration.
     */
    protected function makeView()
    {
        $this->makeIndex();
        $this->makeForm();
    }

    protected function makeIndex(){
        $name = $this->argument('model');
        if ($this->files->exists($path = $this->getViewPath($name))) {
            return $this->error($this->type . ' already exists!');
        }
        $this->makeDirectory($path);
        $this->files->put($path, $this->compileViewStub());
        $this->info('Index created successfully.');
        $this->composer->dumpAutoloads();
    }

    protected function makeForm(){
        $name = $this->argument('model');
        file_put_contents(
            base_path() . '/resources/views/'.str_plural(strtolower($name)).'/'.'form.blade.php',
            $this->compileFormStub()
        );
        $this->info('Form created successfully.');
        $this->composer->dumpAutoloads();
    }

    /**
     * Build the directory for the class if necessary.
     *
     * @param  string $path
     * @return string
     */
    protected function makeDirectory($path)
    {
        if (!$this->files->isDirectory(dirname($path))) {
            $this->files->makeDirectory(dirname($path), 0777, true, true);
        }
    }
    /**
     * Get the destination class path.
     *
     * @param  string $name
     * @return string
     */
    protected function getViewPath($name)
    {
        $name = str_replace($this->getAppNamespace(), '', $name);
        return base_path() . '/resources/views/'.str_plural(strtolower($name)).'/'.'index.blade.php';
    }
    /**
     * Compile the migration stub.
     *
     * @return string
     */
    protected function compileViewStub()
    {
        $stub = $this->files->get(__DIR__ . '/../Stubs/View/index.stub');
        $this->replaceRouteName($stub);
        return $stub;
    }

    /**
     * Compile the migration stub.
     *
     * @return string
     */
    protected function compileFormStub()
    {
        $stub = $this->files->get(__DIR__ . '/../Stubs/View/form.stub');
        $this->replaceRouteName($stub);
        return $stub;
    }

    /**
     * Get the class name for the Eloquent model generator.
     *
     * @return string
     * @param string $stub
     */
    protected function replaceRouteName(&$stub)
    {
        $route = str_plural(strtolower(str_replace('Controller','',$this->argument('model'))));
        $stub = str_replace('{{route}}', $route, $stub);
        return $this;
    }

    /**
     * Get the console command arguments.
     *
     * @return array
     */
    protected function getArguments()
    {
        return [
            ['model', InputArgument::REQUIRED, 'The name of the model'],
        ];
    }

}