<?php
/**
 * Created by PhpStorm.
 * User: Ian Moreno <ian.moreno@republisys.com>
 * Date: 10/12/17 2:47 PM
 */

namespace Rzian\Scaffold;

use Illuminate\Database\Eloquent\Model as BaseModel;
use Rzian\Scaffold\Concerns\CanCount;
use Rzian\Scaffold\Concerns\CanValidate;

abstract class Model extends BaseModel
{
    use CanValidate, CanCount;
}