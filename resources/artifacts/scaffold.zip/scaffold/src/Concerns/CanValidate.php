<?php
/**
 * Created by PhpStorm.
 * User: Ian Moreno <ian.moreno@republisys.com>
 * Date: 11/14/17 8:03 AM
 */

namespace Rzian\Scaffold\Concerns;

use Illuminate\Support\Facades\Validator;

trait CanValidate
{
    /**
     * The validation rules for model attributes.
     *
     * @var array
     */
    protected $rules;

    /**
     * The validator handler for model.
     *
     * @var \Illuminate\Validation\Validator
     */
    protected $validator;

    /**
     * Validates the input requests.
     *
     * @param array $keys
     * @param bool $is_only
     * @return $this
     */
    public function validate(array $keys = [], $is_only = false)
    {
        $this->rules = ! is_array($this->rules) ? array() : $this->rules;

        $keys = array_flip($keys);

        $this->validator = Validator::make(
            $this->attributes,
            $is_only ? array_intersect_key($this->rules, $keys)
                     : array_diff_key($this->rules, $keys)
        );

        return $this;
    }

    /**
     * Checks if there's an error on attributes after validation process.
     *
     * @return bool
     */
    public function hasError()
    {
        if (! $this->validator) // To make sure the validator was instantiated.
        {
            $this->validate();
        }

        return ! $this->validator->passes();
    }

    /**
     * Retrieves error messages.
     *
     * @return \Illuminate\Support\MessageBag
     */
    public function errors()
    {
        return $this->validator->errors();
    }
} 