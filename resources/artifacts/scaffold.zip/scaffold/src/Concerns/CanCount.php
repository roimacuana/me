<?php
/**
 * Created by PhpStorm.
 * User: Ian Moreno <ian.moreno@republisys.com>
 * Date: 11/14/17 8:03 AM
 */

namespace Rzian\Scaffold\Concerns;

use \Exception;

trait CanCount
{
    /**
     * Retrieves total count of a model table.
     *
     * @param string $column
     * @return int
     */
    public static function count($column = 'id')
    {
        return parent::count($column);
    }
}