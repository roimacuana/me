<?php
namespace Roi\Scaffold;
use Illuminate\Support\ServiceProvider;

class GeneratorsServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        $this->registerMigrationGenerator();
        $this->registerModelGenerator();
        $this->registerControllerGenerator();
        $this->registerViewGenerator();
    }

    /**
     * Register the generate:migration generator.
     */
    private function registerMigrationGenerator()
    {
        $this->app->singleton('command.scaffold.migrate', function ($app) {
            return $app['Roi\Scaffold\Commands\MigrationMakeCommand'];
        });
        $this->commands('command.scaffold.migrate');
    }

    /**
     * Register the generate:model generator.
     */
    private function registerModelGenerator()
    {
        $this->app->singleton('command.scaffold.model', function ($app) {
            return $app['Roi\Scaffold\Commands\ModelMakeCommand'];
        });
        $this->commands('command.scaffold.model');
    }

    /**
     * Register the generate:controller generator.
     */
    private function registerControllerGenerator()
    {
        $this->app->singleton('command.scaffold.controller', function ($app) {
            return $app['Roi\Scaffold\Commands\ControllerMakeCommand'];
        });
        $this->commands('command.scaffold.controller');
    }

    /**
     * Register the generate:view generator.
     */
    private function registerViewGenerator()
    {
        $this->app->singleton('command.scaffold.view', function ($app) {
            return $app['Roi\Scaffold\Commands\ViewMakeCommand'];
        });
        $this->commands('command.scaffold.view');
    }

}